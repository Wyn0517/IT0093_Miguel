# Campus Companion — M6

Updated from the current M5 project for Laboratory Exercise 6. Includes the persistent profile photo, campus location awareness, both coding challenges, and an original **snow.json** announcement feed.

## Run on your Mac

1. Extract the ZIP completely and open `CampusCompanion.xcodeproj` in Xcode.
2. Choose the **CampusCompanion** scheme and an iPhone Simulator running iOS 15 or later.
3. Press **Command+B** to build and **Command+R** to run.
4. On **Student Profile**, tap **Change Photo**, choose an image, then stop and relaunch the app to verify restoration.
5. Tap **Remove Photo** to delete the saved image and restore the placeholder. It is disabled when no saved file exists.
6. Tap **Explore Campus**, or open **Campus Announcements** and tap a row, to open the detail screen with the map.
7. Allow location access and set a simulated location in Simulator to see the distance from campus.
8. In **Campus Announcements**, tap Refresh to load the eight original Snow announcements.

No third-party packages or API keys are required. Choose your signing team only if you want to run on a physical iPhone.

## Exercise 6 features

| Requirement | Implementation |
| --- | --- |
| 100 × 100 profile image, Aspect Fill, Clip to Bounds | Storyboard `profileImageView`, centered above the name field |
| Change Photo | `PHPickerViewController`, images only, one selection |
| Picker result | `NSItemProvider.loadObject(ofClass: UIImage.self)`; all UI changes return to the main queue |
| Save image | JPEG quality 0.8, atomic write to Documents/`profilePhoto.jpg` using FileManager |
| Restore image | `loadProfileImageFromDisk()` called alongside UserDefaults restoration in `viewDidLoad()` |
| Remove Photo challenge | `FileManager.removeItem(at:)`, neutral `person.crop.circle` placeholder, disabled without a saved file |
| Location privacy | Exact usage description from the lab in Info.plist |
| Campus map | Storyboard `MKMapView`, 220-point height, 500-meter region centered on the lab coordinate |
| Persistent location manager | Stored property with `CLLocationManagerDelegate` callbacks |
| Authorization | Explicit handling of not determined, when in use, always, denied, restricted, and unknown status |
| Device distance | One-shot `requestLocation()` after authorization, then `CLLocation.distance(from:)` in meters |
| Second landmark challenge | A separate named library coordinate and distinct Campus / Campus Library pin titles |
| Distance remains campus-based | Only the original Campus coordinate is passed into the distance calculation |
| Failure handling | Picker cancellation, unsupported image, save/delete failure, location denial, and location failure preserve a usable screen |

The campus coordinate **14.6255, 121.0034** follows the lab exactly. The library coordinate **14.6260, 121.0039** is a nearby example for the coding challenge, not a surveyed library location. Both pins fit the initial region. The map remains visible without location permission; the distance is straight-line distance to the Campus pin, not walking directions or distance to an announcement's text location.

The profile and detail scenes scroll vertically so the additional controls do not overlap on smaller phones. Profile controls have aligned margins; the new image is centered; the map and labels use consistent spacing. The profile image remains on the device and is not included in the JSON.

## Original Snow JSON

`CampusCompanion/Resources/snow.json` contains eight original, fictional sample announcements dated **November 7, 2026**, with title, date, category, location, priority, and postedBy fields. It is included in the app's Copy Bundle Resources build phase and also provided as a separate file for hosting.

**Default mode: local JSON.** Refresh reads the included file, decodes it, and replaces the Core Data announcements. The navigation prompt reads **Snow feed • Local JSON**, the confirmation is **Snow JSON Loaded**, and the console explicitly says it loaded a local file. This is not a network request.

**Online mode: your own hosted JSON.** The M5 URLSession request, HTTP checks, JSONDecoder, Core Data replacement, byte logging, and **Server Reached** confirmation remain available. To enable that flow, upload `snow.json` and set the single endpoint constant to its real HTTPS Raw URL. Read `SNOW_JSON_SETUP.md` for the steps. No third-party feed address is configured in this version.

Refresh replaces the current collection, including local additions, with whichever feed mode is configured. Initial seed records use the device's current date. Existing persisted records still appear before Refresh; tap Refresh to replace older saved records with the current Snow data. The original M5 Core Data model versions, sorting, table data source, local add/delete, detail navigation, and saved preferences remain in the project.

## Project organization

| Location | Contents |
| --- | --- |
| `CampusCompanion/App/` | App and scene lifecycle, existing Core Data stack |
| `CampusCompanion/Controllers/ViewController.swift` | Profile preferences and photo picker/save/restore/remove |
| `CampusCompanion/Controllers/DetailViewController.swift` | Existing details, two map pins, authorization and device distance |
| `CampusCompanion/Controllers/AnnouncementsViewController.swift` | Local Snow feed and configurable M5 online refresh |
| `CampusCompanion/Models/` | Codable DTO and original / V5 Core Data models |
| `CampusCompanion/Resources/snow.json` | Original sample feed bundled with the app |
| `CampusCompanion/Views/` | Aligned multiline announcement cell |
| `CampusCompanion/Base.lproj/` | Storyboard scenes and launch screen |
| `SNOW_JSON_SETUP.md` | Local editing and GitHub hosting instructions |
| `Submission/` | M6 verification checklist and reflection; prior M5 reflection |

## What was verified here

Static checks cover XML/plist/JSON validity, Xcode project structure, source/resource membership, storyboard outlets/actions and references, model selection, required field types, and map coordinate separation. The ZIP is checked for integrity. This workspace has no Xcode, Apple SDK, or Simulator; build, device behavior, visual layout, photo persistence, permissions, and authentic screenshots must be verified on your Mac using the supplied checklist. No runtime screenshots or passing Xcode results are fabricated.
