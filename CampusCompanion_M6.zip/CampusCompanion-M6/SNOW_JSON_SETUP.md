# Your original snow.json

The original file is named **snow.json**. It contains eight fictional campus announcements created for this project, all dated November 7, 2026 (today when this file was prepared). All six fields are strings and the file's top-level value is an array, matching `AnnouncementDTO`.

## Use it immediately, without hosting

1. Run the project and open Campus Announcements.
2. Tap Refresh. The title **Snow JSON Loaded** confirms that the bundled file was read locally.
3. Inspect the eight rows, including Location and Priority Level.
4. Tap a row to see its details and the M6 campus map.

To edit the local announcements, expand **CampusCompanion → Resources → snow.json** in Xcode. Keep the same keys and JSON punctuation. Rebuild and run, then tap Refresh again. The original file in the ZIP is also available at `CampusCompanion/Resources/snow.json`.

Changing the bundled file alone does not overwrite the Core Data store until you tap Refresh. Uninstalling the app deletes its saved announcements and profile photograph; a normal rebuild/run keeps them.

## Host your own feed for the M5 online request

1. In your GitHub account, create a public repository, for example `snow-campus-api`.
2. Upload the provided **snow.json** into the repository's root and commit it to your chosen branch.
3. Open the file on GitHub, click **Raw**, and copy the resulting HTTPS URL from the browser address bar.
4. Open that URL in Safari. It must show the JSON array, not a GitHub page or a 404 response.
5. In Xcode, open **Controllers → AnnouncementsViewController.swift**.
6. Near the top, find:

   ```swift
   private enum RemoteEndpoint {
       static let announcements: URL? = nil
   }
   ```

7. Replace only `nil` with `URL(string: "...")`, inserting your actual copied HTTPS Raw URL inside the quotes. Keep `URL?` and do not add a force unwrap.
8. Build/run again. The navigation prompt now reads **Snow feed • Online**.
9. Tap Refresh. A successful HTTP request and save produce **Server Reached** with the actual response byte count; the console prints the raw remote JSON.

Setting the constant back to `nil` selects the bundled Snow data again. A failing configured online feed logs its error and leaves the saved records unchanged; it does not silently switch to local data or claim server success.

An online URL is not created merely by naming the file snow.json. The GitHub account name, repository, branch, and filename must all match the location where you upload it. No GitHub content was published as part of this project update.

## Editing rules

- Keep a top-level array: `[` followed by objects and `]`.
- Keep `title`, `date`, and `category` as strings.
- Include `location`, `priority`, and `postedBy` as strings for complete rows.
- The file uses priority values Normal, High, and Urgent. High/Urgent rows receive the existing alert styling.
- Dates use `MMMM d, yyyy`, for example `November 7, 2026`, matching the existing date sorter.
- Do not put a comma after the last object or last field.
- The map uses fixed lab coordinates, independently of these text location names.
