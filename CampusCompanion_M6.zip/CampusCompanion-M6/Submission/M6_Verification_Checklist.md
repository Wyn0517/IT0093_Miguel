# M6 verification on your Mac

These are checks to perform in Xcode / iOS Simulator, not claims of tests already run here. Use authentic screenshots of your own running app if your instructor asks for evidence.

## Build and layout

1. Open CampusCompanion.xcodeproj, select an iPhone Simulator, and press Command+B. Resolve any errors or warnings before submission.
2. Run on a small iPhone and a larger iPhone, then rotate. Check the centered 100 × 100 image, aligned photo buttons, readable labels, 220-point map, and scroll access to every control.
3. Check that the name field, switch, role, date picker, guests stepper, Explore Campus, and Reset Preferences still work. Existing preferences should survive a stop/relaunch cycle.
4. Open announcements and tap a row. Existing detail text must appear above the map, with Location and Priority Level still visible.

## Part 1 — persistent profile photo

1. First launch with no saved image: the neutral person placeholder is visible; Remove Photo is disabled.
2. If the Simulator photo library is empty, use its Add Photos menu or drag a sample photo into Simulator. Import a real sample image before testing the picker.
3. Tap Change Photo: the system picker shows images and allows one selection. Basic picking must not prompt for broad photo-library permission.
4. Cancel the picker: the current image and saved file must be unchanged.
5. Select a photo: it appears in the image view; the status says Photo saved on this device; Remove Photo becomes enabled.
6. Stop the app in Xcode and relaunch without uninstalling. The same image must be restored automatically. This verifies the Documents file, not only an in-memory value.
7. Select a different photo. Relaunch and confirm the new image replaced the old one instead of creating accumulating files.

## Part 3 — Remove Photo challenge

1. Tap Remove Photo after saving a photo.
2. The image must immediately return to the person placeholder and Remove Photo must become disabled.
3. Stop and relaunch. The placeholder must remain, proving profilePhoto.jpg was removed from disk.
4. Reset Preferences clears name/switch/role; the separate Remove Photo action manages the photo.

## Part 2 — map and authorization

1. Open Explore Campus or an announcement detail. The map must appear even before permission is granted.
2. On first permission request, check the reason: Campus Companion uses your location only to show how far you currently are from campus.
3. Grant When In Use permission. In Simulator, choose Features > Location > Custom Location and enter latitude 14.6255, longitude 121.0034. Reopen the detail screen if necessary to trigger a new one-shot location request.
4. Expect approximately 0 meters from campus when the simulated device is exactly at the Campus pin. Actual device readings can vary.
5. Try latitude 14.6265, longitude 121.0034; reopen the detail screen. Expect roughly 111 meters. The displayed measurement is straight-line distance, not a route.
6. Deny permission in a clean Simulator or change the app's permission in Settings, then reopen details. Check the denied message and the still-visible map.
7. With Simulator location set to None, verify the app handles an unavailable location without crashing. A location failure message can take a few seconds to arrive.
8. Permission changes in Settings should update the label when the authorization callback arrives. Restricted access may require a managed device or parental controls to exercise; do not claim that path was tested if unavailable.

## Part 3 — second landmark challenge

1. Both Campus and Campus Library pins must be visible together in the initial 500-meter region. Tap each to see its distinct title.
2. Simulate the device at the library coordinate 14.6260, 121.0039, then reopen details. The distance should be about 77 meters to Campus, not zero to the library. This proves that the added pin does not change the distance reference.
3. The library is a nearby example coordinate for the lab, not a verified building location.

## Original Snow feed and preserved M5 behavior

1. Open Campus Announcements. The prompt should read Snow feed • Local JSON.
2. Tap Refresh: expect Snow JSON Loaded and exactly eight original announcement rows. Check title, date, category, location, and priority against Resources/snow.json.
3. Tap Refresh again: still eight rows, without duplicates.
4. Stop/relaunch: the refreshed rows must remain in Core Data.
5. Check local add, swipe-to-delete, priority styling, and row-to-detail navigation.
6. To test actual M5 networking, first host snow.json and configure the real Raw URL using SNOW_JSON_SETUP.md. Local mode is not evidence of an HTTP request.
7. In online mode, expect Snow feed • Online, raw JSON in the console, and Server Reached with the exact received byte count. Repeat Refresh to confirm no duplicates.
8. Disable the Mac's active internet connection and tap Refresh in online mode. Expect a network diagnostic, unchanged saved data, and the button restored after completion. Local mode intentionally keeps working without internet.

Suggested evidence: a selected profile photo, the same photo after relaunch, the placeholder/disabled Remove Photo after removal, two visible map pins with a numeric campus distance, and a denied-permission screen. Capture a genuine Server Reached alert only if you enable and successfully run the online feed.
