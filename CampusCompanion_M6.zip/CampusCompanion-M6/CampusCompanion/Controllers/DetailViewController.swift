//
//  DetailViewController.swift
//  CampusCompanion
//

import UIKit
import MapKit
import CoreLocation

class DetailViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var campusMapView: MKMapView!
    @IBOutlet weak var distanceLabel: UILabel!

    // Exercise 6's fixed reference coordinate; distance always targets this point.
    private enum CampusLocation {
        static let coordinate = CLLocationCoordinate2D(latitude: 14.6255,
                                                      longitude: 121.0034)
    }

    // A nearby example landmark for the lab's second-annotation challenge.
    private enum LibraryLocation {
        static let coordinate = CLLocationCoordinate2D(latitude: 14.6260,
                                                      longitude: 121.0039)
    }

    // Stored for the lifetime of the screen so delegate callbacks can arrive.
    private let locationManager = CLLocationManager()
    private var hasRequestedAuthorization = false
    private var isRequestingLocation = false

    // MARK: - Exercise 2: values passed from the welcome screen
    var studentName: String = ""
    var notificationsEnabled: Bool = false
    var selectedRole: String = ""
    var eventDate: Date = Date()
    var guestCount: Int = 1

    // MARK: - Exercise 3: announcement passed from the announcements list
    var announcement: CampusAnnouncement?

    override func viewDidLoad() {
        super.viewDidLoad()
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        messageLabel.font = .preferredFont(forTextStyle: .body)
        messageLabel.adjustsFontForContentSizeCategory = true
        distanceLabel.numberOfLines = 0
        distanceLabel.font = .preferredFont(forTextStyle: .subheadline)
        distanceLabel.adjustsFontForContentSizeCategory = true
        campusMapView.layer.cornerRadius = 12
        campusMapView.clipsToBounds = true

        if let announcement = announcement {
            // Core Data generates String? properties, so unwrap each with a safe default.
            let announcementTitle = announcement.title ?? ""
            let category = announcement.category ?? ""
            let date = announcement.date ?? ""
            let priority = announcement.priority ?? "Normal"
            let location = announcement.location ?? "Not specified"
            let postedBy = announcement.postedBy ?? ""

            title = category
            messageLabel.text = """
            \(announcementTitle)

            Category: \(category)
            Date: \(date)
            Location: \(location.isEmpty ? "Not specified" : location)
            Priority Level: \(priority)
            Posted by: \(postedBy)
            """
        } else {
            title = "Campus Events"
            let notificationStatus = notificationsEnabled ? "on" : "off"

            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .none

            messageLabel.text = """
            Welcome, \(studentName)! (\(selectedRole))
            Notifications: \(notificationStatus).
            Event: \(formatter.string(from: eventDate))
            Guests: \(guestCount)
            """
        }

        configureCampusMap()
        // Create/configure the manager on the main thread; its delegates run here too.
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.delegate = self
        updateLocationAuthorization(locationManager)
    }

    // MARK: - Exercise 6: two landmarks, one distance reference
    private func configureCampusMap() {
        campusMapView.delegate = self
        let region = MKCoordinateRegion(center: CampusLocation.coordinate,
                                        latitudinalMeters: 500,
                                        longitudinalMeters: 500)
        campusMapView.setRegion(region, animated: false)

        let campus = MKPointAnnotation()
        campus.coordinate = CampusLocation.coordinate
        campus.title = "Campus"
        campus.subtitle = "Distance reference"

        let library = MKPointAnnotation()
        library.coordinate = LibraryLocation.coordinate
        library.title = "Campus Library"
        library.subtitle = "Example campus landmark"
        // Both points are inside the initial 500 m region, including when denied.
        campusMapView.addAnnotations([campus, library])
    }

    func mapView(_ mapView: MKMapView,
                 viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard annotation is MKPointAnnotation else { return nil }
        let reuseIdentifier = "CampusLandmark"
        let marker = (mapView.dequeueReusableAnnotationView(withIdentifier: reuseIdentifier)
                      as? MKMarkerAnnotationView)
            ?? MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: reuseIdentifier)
        marker.annotation = annotation
        marker.canShowCallout = true
        // Keep both nearby challenge pins visible instead of suppressing a collision.
        marker.displayPriority = .required
        let isLibrary = annotation.coordinate.latitude == LibraryLocation.coordinate.latitude
        marker.markerTintColor = isLibrary ? .systemGreen : .systemBlue
        marker.glyphImage = UIImage(systemName: isLibrary ? "books.vertical.fill" : "graduationcap.fill")
        return marker
    }

    // MARK: - Authorization -> one location request -> distance
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        updateLocationAuthorization(manager)
    }

    private func updateLocationAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .notDetermined:
            distanceLabel.text = "Allow location access to see your distance from campus."
            if !hasRequestedAuthorization {
                hasRequestedAuthorization = true
                manager.requestWhenInUseAuthorization()
            }
        case .authorizedWhenInUse, .authorizedAlways:
            guard !isRequestingLocation else { return }
            distanceLabel.text = "Finding your distance from campus..."
            isRequestingLocation = true
            manager.requestLocation()
        case .denied:
            isRequestingLocation = false
            distanceLabel.text = "Location access denied. Enable it in Settings to see your distance."
        case .restricted:
            isRequestingLocation = false
            distanceLabel.text = "Location access is restricted on this device."
        @unknown default:
            isRequestingLocation = false
            distanceLabel.text = "Location access is unavailable."
        }
    }

    func locationManager(_ manager: CLLocationManager,
                         didUpdateLocations locations: [CLLocation]) {
        isRequestingLocation = false
        // Re-check authorization in case it changed while a request was pending.
        guard manager.authorizationStatus == .authorizedWhenInUse ||
              manager.authorizationStatus == .authorizedAlways else { return }
        guard let currentLocation = locations.last,
              currentLocation.horizontalAccuracy >= 0 else {
            distanceLabel.text = "Your location is unavailable. Try again later."
            return
        }
        let campus = CLLocation(latitude: CampusLocation.coordinate.latitude,
                                longitude: CampusLocation.coordinate.longitude)
        let meters = currentLocation.distance(from: campus)
        distanceLabel.text = String(
            format: "You are approximately %.0f meters from campus.", meters
        )
    }

    // requestLocation() needs a failure delegate as well as a success delegate.
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        isRequestingLocation = false
        print("Location error: \(error.localizedDescription)")
        if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted {
            updateLocationAuthorization(manager)
        } else {
            distanceLabel.text = "Could not find your location. Reopen this screen to try again."
        }
    }
}
