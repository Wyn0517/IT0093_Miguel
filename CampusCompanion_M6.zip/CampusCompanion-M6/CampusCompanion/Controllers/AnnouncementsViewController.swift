//
//  AnnouncementsViewController.swift
//  CampusCompanion
//

import UIKit
import CoreData

// Set this to URL(string: "YOUR_OWN_HTTPS_RAW_LINK_TO_snow.json") after hosting.
// nil deliberately selects the included local snow.json, without a network call.
private enum RemoteEndpoint {
    static let announcements: URL? = nil
}

class AnnouncementsViewController: UITableViewController {

    @IBOutlet private weak var refreshButton: UIBarButtonItem!
    private var isFetchingAnnouncements = false

    // MARK: - Exercise 4: Core Data-backed data source
    private var announcements: [CampusAnnouncement] = []
    private var selectedAnnouncement: CampusAnnouncement?

    private var context: NSManagedObjectContext {
        (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Announcements"
        navigationItem.prompt = RemoteEndpoint.announcements == nil
            ? "Snow feed • Local JSON" : "Snow feed • Online"
        navigationItem.backButtonTitle = "Back"
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 150
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 60, bottom: 0, right: 16)
        seedInitialAnnouncementsIfNeeded()
        loadAnnouncements()
    }

    // MARK: - Exercise 5: request -> decode -> persist -> display
    // Triggered only by Refresh; opening this screen uses the existing local store.
    @IBAction func refreshTapped(_ sender: UIBarButtonItem) {
        fetchAnnouncementsFromServer()
    }

    func fetchAnnouncementsFromServer() {
        guard !isFetchingAnnouncements else { return }
        guard let endpoint = RemoteEndpoint.announcements else {
            loadSnowAnnouncementsFromBundle()
            return
        }
        isFetchingAnnouncements = true
        refreshButton.isEnabled = false

        let request = URLRequest(url: endpoint,
                                 cachePolicy: .reloadIgnoringLocalCacheData,
                                 timeoutInterval: 30)
        let task = URLSession.shared.dataTask(
            with: request
        ) { [weak self] data, response, error in
            // Every exit restores the button on the main thread, including failures.
            defer {
                DispatchQueue.main.async {
                    self?.isFetchingAnnouncements = false
                    self?.refreshButton.isEnabled = true
                }
            }

            // Required order: transport error, HTTP success, then non-nil data.
            if let error = error {
                print("Network error: \(error.localizedDescription)")
                return
            }
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else {
                print("Unexpected server response: \(response.debugDescription)")
                return
            }
            guard let data = data else {
                print("The server returned no data.")
                return
            }

            print("Reached network handler with \(data.count) bytes.")
            // Log the actual response for the lab's console screenshot.
            if let rawJSON = String(data: data, encoding: .utf8) {
                print(rawJSON)
            }

            do {
                let decodedAnnouncements = try JSONDecoder().decode(
                    [AnnouncementDTO].self, from: data
                )
                print("Decoded \(decodedAnnouncements.count) announcements.")
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    // A failed save must not produce a success alert.
                    guard self.replaceAnnouncements(with: decodedAnnouncements) else { return }
                    self.showNetworkConfirmationAlert(byteCount: data.count)
                }
            } catch {
                print("Decoding error: \(error)")
            }
        }
        task.resume()
    }

    // Original sample data is usable before the student hosts a remote feed.
    // It has a separate confirmation so a local read never claims server success.
    private func loadSnowAnnouncementsFromBundle() {
        guard let fileURL = Bundle.main.url(forResource: "snow", withExtension: "json") else {
            print("Snow JSON error: snow.json is missing from the app resources.")
            return
        }
        isFetchingAnnouncements = true
        refreshButton.isEnabled = false
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                let data = try Data(contentsOf: fileURL)
                let dtos = try JSONDecoder().decode([AnnouncementDTO].self, from: data)
                print("Loaded local snow.json with \(data.count) bytes.")
                print(String(data: data, encoding: .utf8) ?? "")
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.isFetchingAnnouncements = false
                    self.refreshButton.isEnabled = true
                    guard self.replaceAnnouncements(with: dtos),
                          self.viewIfLoaded?.window != nil,
                          self.presentedViewController == nil else { return }
                    let alert = UIAlertController(
                        title: "Snow JSON Loaded",
                        message: "Loaded \(dtos.count) announcements from the included snow.json. This is local sample data.",
                        preferredStyle: .alert
                    )
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(alert, animated: true)
                }
            } catch {
                print("Snow JSON error: \(error)")
                DispatchQueue.main.async { [weak self] in
                    self?.isFetchingAnnouncements = false
                    self?.refreshButton.isEnabled = true
                }
            }
        }
    }

    @discardableResult
    func replaceAnnouncements(with dtos: [AnnouncementDTO]) -> Bool {
        // This method is reached on the main queue, matching viewContext's queue.
        let deleteRequest: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        do {
            let existing = try context.fetch(deleteRequest)
            for item in existing { context.delete(item) }
            for dto in dtos {
                let announcement = CampusAnnouncement(context: context)
                announcement.title = dto.title
                announcement.date = dto.date
                announcement.category = dto.category
                announcement.location = dto.location ?? "Not specified"
                announcement.priority = dto.resolvedPriority
                announcement.postedBy = dto.postedBy ?? "Not specified"
            }
            try context.save()
            // Remember even a successful empty feed so relaunch does not reseed it.
            UserDefaults.standard.set(true, forKey: "hasSynchronizedAnnouncements")
            loadAnnouncements()
            tableView.reloadData()
            return true
        } catch {
            context.rollback()
            print("Persistence error: \(error)")
            return false
        }
    }

    func showNetworkConfirmationAlert(byteCount: Int) {
        guard viewIfLoaded?.window != nil, presentedViewController == nil else { return }
        let alert = UIAlertController(
            title: "Server Reached",
            message: "Received \(byteCount) bytes from the announcements endpoint.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    // MARK: - Core Data: seed & fetch
    private func seedInitialAnnouncementsIfNeeded() {
        let request: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        let existingCount = (try? context.count(for: request)) ?? 0
        guard existingCount == 0,
              !UserDefaults.standard.bool(forKey: "hasSynchronizedAnnouncements") else { return }

        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "MMMM d, yyyy"
        let todayDate = formatter.string(from: Date())

        let seeds: [(title: String, date: String, category: String, priority: String, postedBy: String)] = [
            ("Enrollment Period Extended", todayDate, "Registrar",
             "Normal", "Registrar's Office"),
            ("Library Hours Extended for Finals", todayDate, "Library",
             "Normal", "University Library"),
            ("Career Fair 2026", todayDate, "Career Center",
             "Normal", "Career Center"),
            ("Student Council Elections", todayDate, "Student Affairs",
             "Normal", "Student Affairs Office"),
            ("Campus Wi-Fi Maintenance Notice", todayDate, "IT Services",
             "Urgent", "IT Services"),
            ("Intramural Sports Sign-Up", todayDate, "Athletics",
             "Normal", "Athletics Office")
        ]

        for seed in seeds {
            let announcement = CampusAnnouncement(context: context)
            announcement.title = seed.title
            announcement.date = seed.date
            announcement.category = seed.category
            announcement.priority = seed.priority
            announcement.postedBy = seed.postedBy
        }
        try? context.save()
    }

    private func loadAnnouncements() {
        let request: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: true)]
        let fetched = (try? context.fetch(request)) ?? []

        // "date" is stored as text ("August 3, 2026"), so a plain string sort would put
        // "August 10" before "August 3". Re-order by the real calendar date.
        announcements = fetched.sorted { first, second in
            let firstDate = calendarDate(from: first.date ?? "")
            let secondDate = calendarDate(from: second.date ?? "")
            if firstDate != secondDate { return firstDate < secondDate }
            return (first.title ?? "") < (second.title ?? "")
        }
        tableView.reloadData()
    }

    private func calendarDate(from text: String) -> Date {
        let fixedFormatter = DateFormatter()
        fixedFormatter.locale = Locale(identifier: "en_US_POSIX")
        fixedFormatter.dateFormat = "MMMM d, yyyy"
        if let date = fixedFormatter.date(from: text) { return date }

        // New announcements are stamped with the device's locale (.long style).
        let localizedFormatter = DateFormatter()
        localizedFormatter.dateStyle = .long
        localizedFormatter.timeStyle = .none
        return localizedFormatter.date(from: text) ?? .distantFuture
    }

    // MARK: - Actions
    @IBAction func addAnnouncementTapped(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "New Announcement",
                                      message: "Enter a title and category.",
                                      preferredStyle: .alert)
        alert.addTextField { textField in textField.placeholder = "Title" }
        alert.addTextField { textField in textField.placeholder = "Category" }

        let saveAction = UIAlertAction(title: "Save", style: .default) { [weak self, weak alert] _ in
            guard let self = self,
                  let titleText = alert?.textFields?[0].text, !titleText.isEmpty,
                  let categoryText = alert?.textFields?[1].text, !categoryText.isEmpty else { return }

            let newAnnouncement = CampusAnnouncement(context: self.context)
            newAnnouncement.title = titleText
            newAnnouncement.date = DateFormatter.localizedString(from: Date(),
                                                                 dateStyle: .long, timeStyle: .none)
            newAnnouncement.category = categoryText
            newAnnouncement.priority = "Normal"
            newAnnouncement.postedBy = "Student"
            try? self.context.save()
            self.loadAnnouncements()
        }
        alert.addAction(saveAction)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    // MARK: - UITableViewDataSource
    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return announcements.count
    }

    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: "AnnouncementCell", for: indexPath)
            as? AnnouncementCell else {
            return UITableViewCell()
        }
        cell.configure(with: announcements[indexPath.row])
        return cell
    }

    // MARK: - Exercise 4, Part 3: swipe-to-delete
    override func tableView(_ tableView: UITableView,
                            canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    override func tableView(_ tableView: UITableView,
                            commit editingStyle: UITableViewCell.EditingStyle,
                            forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else { return }

        let announcementToDelete = announcements[indexPath.row]
        context.delete(announcementToDelete)
        try? context.save()
        announcements.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: .automatic)
    }

    // MARK: - UITableViewDelegate
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        selectedAnnouncement = announcements[indexPath.row]
        performSegue(withIdentifier: "ShowAnnouncementDetailSegue", sender: self)
    }

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowAnnouncementDetailSegue",
              let destination = segue.destination as? DetailViewController,
              let announcement = selectedAnnouncement else { return }
        destination.announcement = announcement
    }
}
