//
//  ViewController.swift
//  CampusCompanion
//
//  Created by MARK SNOWPHER MIGUEL on 10/17/26.
//

import UIKit
import PhotosUI

// MARK: - Exercise 4: UserDefaults keys (single source of truth)
private enum DefaultsKey {
    static let studentName = "studentName"
    static let notificationsEnabled = "notificationsEnabled"
    static let selectedRoleIndex = "selectedRoleIndex"
}

class ViewController: UIViewController, PHPickerViewControllerDelegate {

    // MARK: - Exercise 6: profile photograph
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var changePhotoButton: UIButton!
    @IBOutlet weak var removePhotoButton: UIButton!
    @IBOutlet weak var photoStatusLabel: UILabel!

    // A fixed filename lets save, restore, and remove address the same file.
    private enum ProfilePhoto {
        static let filename = "profilePhoto.jpg"
    }

    private var profilePhotoURL: URL? {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
            .first?.appendingPathComponent(ProfilePhoto.filename)
    }

    // MARK: - Outlets (Activity 1)
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!

    // MARK: - Outlets (Exercise 2)
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var notifySwitch: UISwitch!
    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!

    // MARK: - Outlets (Exercise 2, Part 3 challenge)
    @IBOutlet weak var eventDatePicker: UIDatePicker!
    @IBOutlet weak var guestsStepper: UIStepper!
    @IBOutlet weak var guestsCountLabel: UILabel!

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.backButtonTitle = "Back"
        // Ensure initial text matches the requirements
        titleLabel.text = "Campus Companion"
        subtitleLabel.text = "Your Campus, In Your Pocket"

        // Event dates cannot be in the past
        eventDatePicker.minimumDate = Date()
        guestsCountLabel.text = "\(Int(guestsStepper.value))"

        // Exercise 4, Part 1: restore persisted values (safe defaults on first launch)
        nameTextField.text = UserDefaults.standard.string(forKey: DefaultsKey.studentName) ?? ""
        notifySwitch.isOn = UserDefaults.standard.bool(forKey: DefaultsKey.notificationsEnabled)
        roleSegmentedControl.selectedSegmentIndex =
            UserDefaults.standard.integer(forKey: DefaultsKey.selectedRoleIndex)

        profileImageView.layer.cornerRadius = 50
        profileImageView.clipsToBounds = true
        profileImageView.isAccessibilityElement = true
        profileImageView.accessibilityLabel = "Profile photo"
        photoStatusLabel.font = .preferredFont(forTextStyle: .footnote)
        photoStatusLabel.adjustsFontForContentSizeCategory = true
        loadProfileImageFromDisk()
    }

    // MARK: - Exercise 6: select -> resolve -> save -> restore
    @IBAction func changePhotoTapped(_ sender: UIButton) {
        view.endEditing(true)
        var configuration = PHPickerConfiguration()
        configuration.filter = .images
        configuration.selectionLimit = 1
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = self
        present(picker, animated: true)
    }

    func picker(_ picker: PHPickerViewController,
                didFinishPicking results: [PHPickerResult]) {
        // Cancel returns no results: retain the existing image and saved file.
        picker.dismiss(animated: true)
        guard let result = results.first else { return }
        let provider = result.itemProvider
        guard provider.canLoadObject(ofClass: UIImage.self) else {
            photoStatusLabel.text = "Please choose a supported image."
            return
        }

        changePhotoButton.isEnabled = false
        removePhotoButton.isEnabled = false
        photoStatusLabel.text = "Loading your photo..."
        // NSItemProvider resolves the image off the main thread.
        provider.loadObject(ofClass: UIImage.self) { [weak self] object, error in
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.changePhotoButton.isEnabled = true
                guard let image = object as? UIImage else {
                    self.updateRemovePhotoButton()
                    self.photoStatusLabel.text = "Could not load this photo. Please try another."
                    if let error = error {
                        print("Could not load profile photo: \(error.localizedDescription)")
                    }
                    return
                }
                // Only confirm a new profile image after its file has been saved.
                guard self.saveProfileImageToDisk(image) else { return }
                self.profileImageView.image = image
                self.profileImageView.accessibilityValue = "Your selected photo"
                self.photoStatusLabel.text = "Photo saved on this device."
            }
        }
    }

    @discardableResult
    func saveProfileImageToDisk(_ image: UIImage) -> Bool {
        guard let data = image.jpegData(compressionQuality: 0.8),
              let fileURL = profilePhotoURL else {
            photoStatusLabel.text = "Could not prepare the photo for saving."
            updateRemovePhotoButton()
            return false
        }
        do {
            // Atomic replacement preserves the previous file if the write fails.
            try data.write(to: fileURL, options: .atomic)
            updateRemovePhotoButton()
            return true
        } catch {
            print("Could not save profile photo: \(error.localizedDescription)")
            photoStatusLabel.text = "Could not save your photo. Please try again."
            updateRemovePhotoButton()
            return false
        }
    }

    func loadProfileImageFromDisk() {
        showProfilePlaceholder()
        if let fileURL = profilePhotoURL,
           let image = UIImage(contentsOfFile: fileURL.path) {
            profileImageView.image = image
            profileImageView.accessibilityValue = "Your saved photo"
            photoStatusLabel.text = "Photo saved on this device."
        }
        updateRemovePhotoButton()
    }

    @IBAction func removePhotoTapped(_ sender: UIButton) {
        guard let fileURL = profilePhotoURL else { return }
        do {
            if FileManager.default.fileExists(atPath: fileURL.path) {
                try FileManager.default.removeItem(at: fileURL)
            }
            showProfilePlaceholder()
            updateRemovePhotoButton()
        } catch {
            print("Could not remove profile photo: \(error.localizedDescription)")
            photoStatusLabel.text = "Could not remove your photo. Please try again."
            updateRemovePhotoButton()
        }
    }

    private func showProfilePlaceholder() {
        profileImageView.image = UIImage(systemName: "person.crop.circle")
        profileImageView.tintColor = .secondaryLabel
        profileImageView.accessibilityValue = "No photo selected"
        photoStatusLabel.text = "Choose a photo for your profile."
    }

    private func updateRemovePhotoButton() {
        guard let fileURL = profilePhotoURL else {
            removePhotoButton.isEnabled = false
            return
        }
        removePhotoButton.isEnabled = FileManager.default.fileExists(atPath: fileURL.path)
    }

    // MARK: - Actions
    @IBAction func exploreButtonTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()
        let enteredName = nameTextField.text ?? ""

        // Exercise 4, Part 1: save captured values before the segue runs
        UserDefaults.standard.set(enteredName, forKey: DefaultsKey.studentName)
        UserDefaults.standard.set(notifySwitch.isOn, forKey: DefaultsKey.notificationsEnabled)
        UserDefaults.standard.set(roleSegmentedControl.selectedSegmentIndex,
                                  forKey: DefaultsKey.selectedRoleIndex)

        performSegue(withIdentifier: "ShowDetailSegue", sender: self)
    }

    // Exercise 4, Part 3: clear saved values and reset the fields immediately
    @IBAction func resetPreferencesTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()

        UserDefaults.standard.removeObject(forKey: DefaultsKey.studentName)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.notificationsEnabled)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.selectedRoleIndex)

        nameTextField.text = ""
        notifySwitch.setOn(false, animated: true)
        roleSegmentedControl.selectedSegmentIndex = 0
    }

    @IBAction func guestsStepperChanged(_ sender: UIStepper) {
        guestsCountLabel.text = "\(Int(sender.value))"
    }

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Only the "Explore Campus" segue carries data. The "Campus Announcements"
        // segue has no identifier and is ignored here.
        guard segue.identifier == "ShowDetailSegue",
              let destination = segue.destination as? DetailViewController else {
            return
        }

        let enteredName = nameTextField.text?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        destination.studentName = enteredName.isEmpty ? "Student" : enteredName
        destination.notificationsEnabled = notifySwitch.isOn
        destination.selectedRole = roleSegmentedControl.selectedSegmentIndex == 0
            ? "Student" : "Faculty"
        destination.eventDate = eventDatePicker.date
        destination.guestCount = max(Int(guestsStepper.value), 1)
    }
}
