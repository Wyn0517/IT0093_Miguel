import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var notifySwitch: UISwitch!
    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!
    @IBOutlet weak var eventDatePicker: UIDatePicker!
    @IBOutlet weak var guestsStepper: UIStepper!

    override func viewDidLoad() {
        super.viewDidLoad()

        titleLabel.text = "Campus Companion"
        subtitleLabel.text = "Your Campus, In Your Pocket"
        title = "Campus Companion"

        if roleSegmentedControl.numberOfSegments >= 2 {
            roleSegmentedControl.setTitle("Student", forSegmentAt: 0)
            roleSegmentedControl.setTitle("Faculty", forSegmentAt: 1)
            roleSegmentedControl.selectedSegmentIndex = 0
        }

        notifySwitch.isOn = false

        guestsStepper.minimumValue = 0
        guestsStepper.maximumValue = 20
        guestsStepper.stepValue = 1
        guestsStepper.value = 0

        eventDatePicker.datePickerMode = .date

        nameTextField.returnKeyType = .done
        nameTextField.addTarget(
            self,
            action: #selector(doneEditingName),
            for: .editingDidEndOnExit
        )
    }

    @objc private func doneEditingName() {
        nameTextField.resignFirstResponder()
    }

    @IBAction func exploreButtonTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()
        performSegue(withIdentifier: "ShowDetailSegue", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowDetailSegue" else {
            return
        }

        let destination: DetailViewController?

        if let navigationController = segue.destination as? UINavigationController {
            destination = navigationController.topViewController as? DetailViewController
        } else {
            destination = segue.destination as? DetailViewController
        }

        guard let destination = destination else {
            print("Error: Destination is not DetailViewController.")
            return
        }

        let enteredName = nameTextField.text ?? ""
        let trimmedName = enteredName.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        destination.studentName = trimmedName.isEmpty
            ? "Student"
            : trimmedName

        destination.wasDefaultNameApplied = trimmedName.isEmpty
        destination.notificationsEnabled = notifySwitch.isOn

        let selectedIndex = roleSegmentedControl.selectedSegmentIndex
        destination.selectedRole = selectedIndex == 0
            ? "Student"
            : "Faculty"

        destination.preferredEventDate = eventDatePicker.date
        destination.numberOfGuests = Int(guestsStepper.value)
    }
}
