import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var explanatoryLabel: UILabel!

    var studentName: String = ""
    var notificationsEnabled: Bool = false
    var selectedRole: String = ""

    var preferredEventDate: Date = Date()
    var numberOfGuests: Int = 0

    var wasDefaultNameApplied: Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Campus Events"
        view.backgroundColor = .systemBackground

        guard let messageLabel = messageLabel,
              let explanatoryLabel = explanatoryLabel else {
            print("Error: Detail screen outlets are not connected.")
            return
        }

        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none

        let dateString = formatter.string(from: preferredEventDate)
        let notificationStatus = notificationsEnabled ? "on" : "off"
        let roleText = selectedRole.isEmpty ? "Student" : selectedRole
        let nameText = studentName.isEmpty ? "Student" : studentName

        let fullMessage = """
        Welcome, \(nameText)! (\(roleText))
        Notifications: \(notificationStatus)
        Event date: \(dateString)
        Guests: \(numberOfGuests)
        """

        messageLabel.text = fullMessage
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        messageLabel.font = UIFont.preferredFont(forTextStyle: .body)

        explanatoryLabel.text = "Text field left empty — default name applied"
        explanatoryLabel.textAlignment = .center
        explanatoryLabel.numberOfLines = 0
        explanatoryLabel.textColor = .secondaryLabel
        explanatoryLabel.font = UIFont.preferredFont(forTextStyle: .footnote)
        explanatoryLabel.isHidden = !wasDefaultNameApplied
    }
}
