//
//  ViewController.swift
//  CampusCompanion
//
//  Created by MARK SNOWPHER MIGUEL on 9/19/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Ensure initial text matches the requirements
        titleLabel.text = "Campus Companion"
        subtitleLabel.text = "Your Campus, In Your Pocket"
    }

    @IBAction func getStartedTapped(_ sender: UIButton) {
        // Update subtitle when the button is tapped
        subtitleLabel.text = "Let's get started!"
    }

}
